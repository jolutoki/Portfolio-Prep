import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.ImageIcon;

public class SlideShow extends JFrame {

//Declare Variables
private JPanel slidePane;
private JPanel textPane;
private JPanel buttonPane;
private CardLayout card;
private CardLayout cardText;
private JButton btnPrev;
private JButton btnNext;
private JLabel lblSlide;
private JLabel lblTextArea;

/**
* Create the application.
*/
public SlideShow() throws HeadlessException {
initComponent();
}

/**
* Initialize the contents of the frame.
*/
private void initComponent() {
//Initialize variables to empty objects
card = new CardLayout();
cardText = new CardLayout();
slidePane = new JPanel();
textPane = new JPanel();
textPane.setBackground(Color.BLUE);
textPane.setBounds(5, 470, 790, 50);
textPane.setVisible(true);
buttonPane = new JPanel();
btnPrev = new JButton();
btnNext = new JButton();
lblSlide = new JLabel();
lblTextArea = new JLabel();

//Setup frame attributes
setSize(800, 600);
setLocationRelativeTo(null);
setTitle("Top 5 Detox/Wellness Destinations Slide Show");
getContentPane().setLayout(new BorderLayout(10, 50));
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

//Setting the layouts for the panels
slidePane.setLayout(card);
textPane.setLayout(cardText);

//logic to add each of the slides and text
for (int i = 1; i <= 5; i++) {
lblSlide = new JLabel();
lblTextArea = new JLabel();

//Set the images and text based on the requirements
ImageIcon slide = new ImageIcon("slide" + i + ".jpg");
lblSlide.setIcon(slide);

String text = "";
switch(i) {
 case 1:
   text = "Welcome to the top 5 detox/wellness destinations in the world!";
   break;
 case 2:
   text = "Destination 1: Lagos, Nigeria - Enjoy a refreshing getaway";
   break;
 case 3:
   text = "Destination 2: Accra, Ghana - Akwaaba water fall view";
   break;
 case 4:
   text = "Destination 3: Maldives - Inspired by herbs and nature";
   break;
 case 5:
   text = "Destination 4: Calabar, Nigeria- Obudu cattle ranch beach retreat"; break; case 6: text = "Destination 5: India - Embrace spirituality at an ashram"; break; }

lblTextArea.setText(text);

//Add slide and text to panels slidePane.add(lblSlide, "Slide" + i); textPane.add(lblTextArea, "Text" + i); }

//Setup button attributes btnPrev.setText("Prev"); btnNext.setText("Next");

//Add buttons to buttonPane buttonPane.add(btnPrev); buttonPane.add(btnNext); buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER));

//Add panels to the frame getContentPane().add(slidePane, BorderLayout.CENTER); getContentPane().add(textPane, BorderLayout.SOUTH); getContentPane().add(buttonPane, BorderLayout.NORTH);

//Action listener for prev button btnPrev.addActionListener(new ActionListener() {

@Override public void actionPerformed(ActionEvent e) { card.previous(slidePane); cardText.previous(textPane); } });

//Action listener for next button btnNext.addActionListener(new ActionListener() {

@Override public void actionPerformed(ActionEvent e) { card.next(slidePane); cardText.next(textPane); } }); }

/**

Launch the application. */ public static void main(String[] args) { EventQueue.invokeLater(new Runnable() { public void run() { try { SlideShow frame = new SlideShow(); frame.setVisible(true); } catch (Exception e) { e.printStackTrace(); } } }); } }
